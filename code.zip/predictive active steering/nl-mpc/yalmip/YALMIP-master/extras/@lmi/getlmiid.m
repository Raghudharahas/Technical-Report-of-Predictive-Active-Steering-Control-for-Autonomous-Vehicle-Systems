function id = getlmiid(F)

id = F.LMIid;
