function x = binary(x)
% binary (overloaded)

x = binary(sdpvar(x));