function Z=setoperatorname(Z,name)

Z.extra.opname=name;