function x = clearconicinfo(x)
x.conicinfo = [0 0];

