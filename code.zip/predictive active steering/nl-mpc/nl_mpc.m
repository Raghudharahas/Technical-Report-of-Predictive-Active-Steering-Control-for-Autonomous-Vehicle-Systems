clc; 
clear all; 
close all;
%%

%%
v = 7; % speed of vehicle in m/s,
vx = v; % longitudinal speed

Np = 7; % prediction horizon 
Nc = 3; % control horizon 
sim_time = 0.0;
t = 1;
dt = 0.05; %sample time

%Physical parameters of Car
m = 2050; % in Kg from paper
Iz = 3344; % from paper
a = 1.5; lf = a; %length from CoG to front axle in meters
b = 1.4; lr = b; %length from CoG to back axle in meters

%%
%TIRE MODEL
Fz = (1/2) * (m * 9.81) / 1000; %force in K-newtons
a1 = -22.1; a2 = 1011; a3 = 1078; a4 = 1.82; a5 = 0.208; 
a6 = 0.000; a7 = -0.354; a8 = 0.707; 

% taking these values as per the previous reference
C = 1.30;
D =  1.0 * m * 9.81 / 2.0; %a1 * (Fz^2) + a2 * Fz; 
% BCD = a3 * sin(a4 * atan(a5 * Fz)); 
B = 1.0; % BCD / (C * D); 
%E = a6 * (Fz^2) + a7 * Fz + a8;


%%
%Declare State and Input Variables
xi = sdpvar(5,Np,'full'); % state vector
u = sdpvar(1,Nc,'full'); % Delta = steering angle
%declare the starting state zo. 
xi_t(:,1) = [0 0 0 0 0]'; % initial state

%%

Time = [sim_time];
Logs = [];

while( sim_time < 12)
    
    
    %Initial z value goes into constrains
    Constr = [xi(:,1) == xi_t(:,t)];
    %%
    %Initial constrainst
     for i= 1:1:Np
            Constr = [Constr ];
     end
    %% ADD constraints
      
    for j = 1:1:Nc-1
        
        alphaF = u(1,j) - atan2((xi(4,j)+ lf * xi(5,j)),vx ) ;
        alphaR = -atan2((xi(4,j) - xi(5,j) * lr) , vx );
        
        FyF = D * sin(C * atan(B * alphaF));
        FyR = D * sin(C * atan(B * alphaR));
        
        Constr = [Constr, ...
        %DYNAMIC EQUATIONS OF THE CAR
        xi(1,j+1) == xi(1,j) + (vx * cos(xi(3,j)) - xi(4,j) * sin(xi(3,j))) *dt, ... %X
        xi(2,j+1) == xi(2,j) + (vx * sin(xi(3,j)) + xi(4,j) * cos(xi(3,j))) *dt,... %Y
        xi(3,j+1) == xi(3,j) + xi(5,j) * dt,... %psi => yaw angle
        xi(4,j+1) == xi(4,j) + ((1/m) * (FyF * cos(u(1,j)) + FyR) - vx * xi(5,j)) *dt,... %vy
        xi(5,j+1) == xi(5,j) + (1 / Iz) * ( lf * FyF * cos(u(1,j)) - lr * FyR) * dt,... %r => yaw rate
        
        %% Vy constraints
        %-5 <= xi(4,j+1) <= 5, ...%20m/s =72km/h
        
        %% Input constraints
        -1.5*pi/180 <= u(1,j+1) - u(1,j) <= 1.5*pi/180, ...
        
        -10*pi/180 <= u(1,j) <= 10*pi/180, ...
        ];
    end
    
    for j = Nc:1:Np-1
        
        alphaF = u(1,Nc-1) - atan2((xi(4,j)+ lf * xi(5,j)),vx ) ;
        alphaR = -atan2((xi(4,j) - xi(5,j) * lr) , vx );
        FyF = D * sin(C * atan(B * alphaF));
        FyR = D * sin(C * atan(B * alphaR));
        
        Constr = [Constr,...
        
        %DYNAMIC EQUATIONS OF THE CAR
        xi(1,j+1) == xi(1,j) + (vx * cos(xi(3,j)) - xi(4,j) * sin(xi(3,j))) * dt,...  %X
        xi(2,j+1) == xi(2,j) + (vx * sin(xi(3,j)) + xi(4,j) * cos(xi(3,j))) * dt,... %Y
        xi(3,j+1) == xi(3,j) + xi(5,j) * dt,... %psi => yaw angle
        xi(4,j+1) == xi(4,j) + ((1 / m) * (FyF * cos(u(1,Nc-1)) + FyR) - vx * xi(5,j)) *dt,... %vy
        xi(5,j+1) == xi(5,j) + (1 / Iz) * ( lf * FyF * cos(u(1,Nc-1)) - lr * FyR) * dt  %r => yaw rate
        
        ];
    end
        
    %%
    % COST FUNCTION
    [ref_Y, ref_psi] = trajectory_generator(xi_t(1,t));
    
    ref_Y_Log(t+1) = ref_Y;
    ref_psi_Log(t+1) = ref_psi; 
    
    Cost = 0;
    
    for k = 1:Np
        
        [ref_Y, ref_psi] = trajectory_generator( xi_t(1,t) + v * (k - 1) * dt );
        
        Cost = Cost + 5 * (ref_Y - xi(2,k))^2 + ...
                      100 * (ref_psi - xi(3,k))^2; 
        
    end
    
    for k = 1:Nc-1
        
        Cost = Cost + 0.1*(u(1,k+1) - u(1,k))^2;
        
    end
    %%
    %Solve Optimization Problem
    options = sdpsettings('solver', 'fmincon', 'verbose', 0, 'debug', 0);
    solution =  solvesdp(Constr,Cost,options);
    
    %display a timer for ease of reading
    disp(['t= ',num2str(t * dt),' of ',num2str(sim_time),...
          ' seconds in increments of ',num2str(dt),' seconds']); %visual timer
    %%
    %use the optmized U of the solver and save them.
    u_star(:,t) = double(u(:,1)); %Use only the first value of the optimized solution
    zopen{1,t} = double(xi);
        
    %Update the Alfas and Forces.
    alphaF(t) = double( u_star(1,t) - atan2( (xi_t(4,t) + lf * xi_t(5,t)), vx));
    alphaR(t) = double( atan2((lr * xi_t(5,t)- xi_t(4,t)) , vx ) );
    FyF(t) = D * sin(C * atan(B * alphaF(t))); 
    FyR(t) = D * sin(C * atan(B * alphaR(t))); 
    
    % the first value of the optimized U + the z to predict the next z.
    xi_t(1,t+1) = xi_t(1,t) + (vx * cos(xi_t(3,t)) - xi_t(4,t) * sin(xi_t(3,t))) *dt; %X
    xi_t(2,t+1) = xi_t(2,t) + (vx*sin(xi_t(3,t)) + xi_t(4,t) * cos(xi_t(3,t))) * dt; %Y
    xi_t(3,t+1) = xi_t(3,t) + xi_t(5,t)*dt; % psi => yaw angle
    xi_t(4,t+1) = xi_t(4,t) + ((1 / m) * (FyF(t) * cos(u_star(1,t)) + FyR(t)) - vx * xi_t(5,t)) *dt; %vy
    xi_t(5,t+1) = xi_t(5,t) + (1 / Iz) * ( lf * FyF(t) * cos(u_star(1,t)) - lr * FyR(t)) * dt; %r => yaw rate
    
   
    %%
    %PLOT OF X VS Y, SIMULATION MPC VS REFERENCE
    plot(xi_t(1,:),xi_t(2,:),'b--o','LineWidth',2); hold on; %Plot open loop

    title('X vs Y MPC SIMULATION');
    
    %%
    
    Logs = [Logs; double(xi_t(3,t+1) - xi_t(3,t)),...
                  double(xi_t(2,t+1) - xi_t(2,t)),...
                  double(alphaF(1,t)),...
                  double(alphaR(1,t)),...
                  double(FyF(1,t)),...
                  double(FyR(1,t)),...
                  double(solution.solvertime)];  
    
    u_star(1,t);
    t = t + 1;
    sim_time = sim_time + dt;
    Time = [Time; sim_time];
end
% Extract relevant columns from the Logs
delta_psi = Logs(:, 1);
delta_Y = Logs(:, 2);

% Calculate RMS values
Y_rms = sqrt(mean(delta_Y.^2));
Yaw_rms = sqrt(mean(delta_psi.^2));

% Display the RMS values
disp(['Y RMS: ', num2str(Y_rms)]);
disp(['Yaw RMS: ', num2str(Yaw_rms)]);


Plotter;
