function f = sum_square(x)    
x = x.^2;
f = sum(x);
