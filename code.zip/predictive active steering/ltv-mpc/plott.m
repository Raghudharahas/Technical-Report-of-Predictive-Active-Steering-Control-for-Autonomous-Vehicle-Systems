% Define your data for the second set of plots here

% Creating a figure with multiple subplots
figure

% First subplot
subplot(4,1,1)
hold on
title('$Y$',...
    'fontsize',18, 'fontweight','b', 'interpreter', 'latex')
plot(t, xi_ac(4,:), 'LineWidth', 2, 'Color', 'b') %  data for Y
grid on

plot(t, eta_true(1,:), ':', 'Color', 'r', 'LineWidth', 2) % Reference data for Y
legend('Actual', 'Reference')
ylabel('$Y [m]$', 'Interpreter', 'latex')
hold off

% Second subplot
subplot(4,1,2)
hold on
title('$Yaw$',...
      'fontsize',18, 'fontweight','b', 'interpreter', 'latex')
plot(t, xi_ac(3,:)*180/pi, 'LineWidth', 2, 'Color', 'b') % Your data for psi
grid on

plot(t, eta_true(2,:)*180/pi, ':', 'Color', 'r', 'LineWidth', 2) % Reference data for psi
legend('Actual', 'Reference')

ylabel('$\psi [deg]$', 'Interpreter', 'latex')
hold off

% Third subplot
subplot(4,1,3)
hold on
title('$Yaw\,\,rate$',...
      'fontsize',18, 'fontweight','b', 'interpreter', 'latex')
plot(t, xi_ac(2,:)*180/pi, 'LineWidth', 2, 'Color', 'b') % Your data for d psi/dt
grid on
plot(t, eta_true(3,:)*180/pi, ':', 'Color', 'r', 'LineWidth', 2) % Reference data for d psi/dt
legend('Actual', 'Reference')

ylabel('$\frac{d \psi}{dt} [deg/s]$', 'Interpreter', 'latex')
hold off
 
% Fourth subplot
subplot(4,1,4)
hold on
title('$Steer\,\,Angle$',...
      'fontsize',18, 'fontweight','b', 'interpreter', 'latex')
plot(t, u_ac*180/pi, 'LineWidth', 2, 'Color', 'b') % Your data for u
grid on

ylabel('$u [deg]$', 'Interpreter', 'latex')
xlabel('time [s]')
hold off

% Adjusting figure properties
sgtitle('Plotted Results at Current Settings', 'Interpreter', 'latex')

% 
% % RMS for Y
% rms_Y = rms(xi_ac(4, :) - eta_true(1, :));
% 
% % RMS for Yaw
% rms_Yaw = rms(xi_ac(3, :) * 180 / pi - eta_true(2, :));
% 
% % RMS for Yaw rate
% rms_YawRate = rms(xi_ac(2, :) * 180 / pi - eta_true(3, :));
% 
% % RMS for Steer Angle
% rms_SteerAngle = rms(u_ac * 180 / pi);
% 
% % Display the results
% disp(['RMS for Y: ', num2str(rms_Y)]);
% disp(['RMS for Yaw: ', num2str(rms_Yaw)]);
% disp(['RMS for Yaw Rate: ', num2str(rms_YawRate)]);
% disp(['RMS for Steer Angle: ', num2str(rms_SteerAngle)]);
% % Adding any final touches or specific adjustments would go here
