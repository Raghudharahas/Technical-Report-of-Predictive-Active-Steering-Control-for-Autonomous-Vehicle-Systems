function [cost,X_predict,Y_predict] = costfunction(x, State_Initial, Np, Nc,T,...
    etaref1,etaref2,etaref3,Q,R,Ak,Bk,xdot,tiempo,rho)
cost = 0; 
l = 1;
% Y, psi, psi_doot
delta_f = zeros(Np,1); %Control amount delta_f
Ts = 0.05;
for i =1:1:Np+1
    gr(i)=x(i);
end

% gr(Np+1) be epsilon

for i =1:1:Np
    if i == 1        
        xi_h(:,1)=State_Initial;

    else
        if(i>2 && i<=Np-2 && Np >4)
            delu(i-2)= gr(i) - gr(i-1);
        end
        delta_f(i,1) = gr(i);
        xi_h(:,i)= Ak*xi_h(:,i-1)+Bk*[delta_f(i,1);1];  % This makes the MPC linear, making this Nonlinear state update requires symbolic math engine, increasing time and effectiveness of algorithm!
        tiempo= tiempo + Ts;

    end
end

eta_h= [0,0,0,1;0,0,1,0;0,1,0,0]*xi_h;

if(Np > 4)
    cost = Q(1,1)*sum_square(eta_h(1,:)-etaref1) ...
        +Q(2,2)*sum_square(eta_h(2,:)-etaref2) ...
        +Q(3,3)*sum_square(eta_h(3,:)-etaref3) ...
        +R*sum_square(delu(1:Np-4)) ...
        +rho*gr(Np+1);
else
    cost = Q(1,1)*sum_square(eta_h(1,:)-etaref1) ...
        +Q(2,2)*sum_square(eta_h(2,:)-etaref2) ...
        +Q(3,3)*sum_square(eta_h(3,:)-etaref3) ...
        +rho*gr(Np+1);
end
 

